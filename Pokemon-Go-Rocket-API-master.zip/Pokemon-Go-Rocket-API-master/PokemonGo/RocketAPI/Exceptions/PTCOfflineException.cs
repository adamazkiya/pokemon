﻿#region

using System;

#endregion

namespace PokemonGo.RocketAPI.Exceptions
{
    public class PtcOfflineException : Exception
    {
    }
}